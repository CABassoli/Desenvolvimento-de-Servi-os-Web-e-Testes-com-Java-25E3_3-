package app.handlers;

import io.javalin.http.Context;
import io.javalin.http.Handler;

import java.util.Map;

public class EchoHandler implements Handler {
    
    @Override
    public void handle(Context ctx) throws Exception {
        try {
            Map<String, Object> requestBody = ctx.bodyAsClass(Map.class);
            ctx.json(requestBody);
        } catch (Exception e) {
            ctx.status(400).json(Map.of("error", "Invalid JSON format"));
        }
    }
}