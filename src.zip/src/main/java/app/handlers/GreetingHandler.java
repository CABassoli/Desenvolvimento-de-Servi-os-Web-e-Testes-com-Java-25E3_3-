package app.handlers;

import io.javalin.http.Context;
import io.javalin.http.Handler;

import java.util.Map;

public class GreetingHandler implements Handler {
    
    @Override
    public void handle(Context ctx) throws Exception {
        String nome = ctx.pathParam("nome");
        String mensagem = "Olá, " + nome + "!";
        
        Map<String, String> response = Map.of(
            "mensagem", mensagem
        );
        
        ctx.json(response);
    }
}