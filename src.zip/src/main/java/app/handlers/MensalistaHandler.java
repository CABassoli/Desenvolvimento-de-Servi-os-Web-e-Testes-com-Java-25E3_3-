package app.handlers;

import io.javalin.http.Context;
import io.javalin.http.Handler;
import app.models.Mensalista;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MensalistaHandler {
    
    private static final Map<String, Mensalista> mensalistas = new HashMap<>();
    
    public void create(Context ctx) throws Exception {
        try {
            Mensalista mensalista = ctx.bodyAsClass(Mensalista.class);
            
            if (mensalista.getMatricula() == null || mensalista.getMatricula().isEmpty()) {
                ctx.status(400).json(Map.of("error", "Matrícula é obrigatória"));
                return;
            }
            
            if (mensalista.getNome() == null || mensalista.getNome().isEmpty()) {
                ctx.status(400).json(Map.of("error", "Nome é obrigatório"));
                return;
            }
            
            if (mensalista.getNome().length() < 3) {
                ctx.status(400).json(Map.of("error", "Nome deve ter pelo menos 3 caracteres"));
                return;
            }
            
            if (!mensalista.getMatricula().matches("^[a-zA-Z0-9]+$")) {
                ctx.status(400).json(Map.of("error", "Matrícula deve ser alfanumérica"));
                return;
            }
            
            if (mensalistas.containsKey(mensalista.getMatricula())) {
                ctx.status(409).json(Map.of("error", "Mensalista com esta matrícula já existe"));
                return;
            }
            
            mensalistas.put(mensalista.getMatricula(), mensalista);
            ctx.status(201).json(mensalista);
        } catch (Exception e) {
            ctx.status(400).json(Map.of("error", "Dados inválidos"));
        }
    }
    
    public void getByMatricula(Context ctx) throws Exception {
        String matricula = ctx.pathParam("matricula");
        Mensalista mensalista = mensalistas.get(matricula);
        
        if (mensalista == null) {
            ctx.status(404).json(Map.of("error", "Mensalista não encontrado"));
            return;
        }
        
        ctx.status(200).json(mensalista);
    }
    
    public void getAll(Context ctx) throws Exception {
        List<Mensalista> lista = new ArrayList<>(mensalistas.values());
        ctx.status(200).json(lista);
    }
    
    public static void clearAll() {
        mensalistas.clear();
    }
}