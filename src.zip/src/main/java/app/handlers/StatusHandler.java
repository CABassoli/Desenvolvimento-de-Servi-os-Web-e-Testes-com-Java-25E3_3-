package app.handlers;

import io.javalin.http.Context;
import io.javalin.http.Handler;

import java.time.Instant;
import java.time.format.DateTimeFormatter;
import java.util.Map;

public class StatusHandler implements Handler {
    
    @Override
    public void handle(Context ctx) throws Exception {
        String timestamp = DateTimeFormatter.ISO_INSTANT.format(Instant.now());
        
        Map<String, String> response = Map.of(
            "status", "ok",
            "timestamp", timestamp
        );
        
        ctx.json(response);
    }
}