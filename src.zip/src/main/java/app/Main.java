package app;

import io.javalin.Javalin;
import io.javalin.http.Context;
import io.javalin.json.JavalinJackson;
import app.handlers.StatusHandler;
import app.handlers.EchoHandler;
import app.handlers.GreetingHandler;
import app.handlers.MensalistaHandler;

import java.time.Instant;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.HashMap;

/**
 * Classe principal da API REST Javalin Demo
 * 
 * Endpoints disponíveis:
 * GET /hello - Retorna "Hello, Javalin!"
 * GET /status - Retorna JSON com status e timestamp
 * POST /echo - Ecoa de volta a mensagem JSON recebida
 * GET /saudacao/{nome} - Retorna saudação com parâmetro de caminho
 * 
 * Para testar com curl:
 * curl http://localhost:5000/hello
 * curl http://localhost:5000/status
 * curl -X POST -H "Content-Type: application/json" -d '{"mensagem":"Teste"}' http://localhost:5000/echo
 * curl http://localhost:5000/saudacao/João
 */
public class Main {
    
    public static void main(String[] args) {
        Javalin app = createApp();
        app.start(5000);
    }
    
    public static Javalin createApp() {
        Javalin app = Javalin.create(config -> {
            config.jsonMapper(new JavalinJackson());
        });
        
        // Inicializa os handlers
        StatusHandler statusHandler = new StatusHandler();
        EchoHandler echoHandler = new EchoHandler();
        GreetingHandler greetingHandler = new GreetingHandler();
        MensalistaHandler mensalistaHandler = new MensalistaHandler();
        
        // GET / - Página de documentação da API
        app.get("/", ctx -> {
            ctx.html(getApiDocumentationPage());
        });
        
        // GET /hello - Resposta simples em texto
        app.get("/hello", ctx -> {
            ctx.result("Hello, Javalin!");
        });
        
        // GET /status - Resposta JSON com status e timestamp
        app.get("/status", statusHandler::handle);
        
        // POST /echo - Ecoa de volta o JSON recebido
        app.post("/echo", echoHandler::handle);
        
        // GET /saudacao/{nome} - Saudação com parâmetro de caminho
        app.get("/saudacao/{nome}", greetingHandler::handle);
        
        // Endpoints de Mensalista
        app.post("/mensalista", mensalistaHandler::create);
        app.get("/mensalista/{matricula}", mensalistaHandler::getByMatricula);
        app.get("/mensalistas", mensalistaHandler::getAll);
        
        // Tratamento global de exceções
        app.exception(Exception.class, (e, ctx) -> {
            ctx.status(500).json(Map.of("error", "Internal server error"));
            e.printStackTrace();
        });
        
        return app;
    }
    
    private static String getApiDocumentationPage() {
        return """
        <!DOCTYPE html>
        <html lang="pt-BR">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>API REST - Javalin Demo</title>
            <style>
                * { margin: 0; padding: 0; box-sizing: border-box; }
                body { 
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    min-height: 100vh;
                    padding: 20px;
                }
                .container { 
                    max-width: 1000px; 
                    margin: 0 auto; 
                    background: white;
                    border-radius: 20px;
                    box-shadow: 0 20px 60px rgba(0,0,0,0.3);
                    overflow: hidden;
                }
                .header {
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    color: white;
                    padding: 40px;
                    text-align: center;
                }
                .header h1 { font-size: 2.5em; margin-bottom: 10px; }
                .header p { font-size: 1.1em; opacity: 0.9; }
                .content { padding: 40px; }
                .section-title {
                    font-size: 1.5em;
                    color: #667eea;
                    margin: 30px 0 20px 0;
                    padding-bottom: 10px;
                    border-bottom: 2px solid #e5e7eb;
                }
                .endpoint {
                    background: #f8f9fa;
                    border-left: 4px solid #667eea;
                    padding: 20px;
                    margin-bottom: 20px;
                    border-radius: 8px;
                    transition: transform 0.2s;
                }
                .endpoint:hover {
                    transform: translateY(-2px);
                    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
                }
                .endpoint h3 { 
                    color: #667eea; 
                    margin-bottom: 10px;
                    display: flex;
                    align-items: center;
                    gap: 10px;
                }
                .method { 
                    display: inline-block;
                    padding: 4px 12px;
                    border-radius: 4px;
                    font-size: 0.85em;
                    font-weight: bold;
                }
                .get { background: #10b981; color: white; }
                .post { background: #f59e0b; color: white; }
                .endpoint p { margin: 10px 0; color: #555; line-height: 1.6; }
                .test-btn {
                    background: #667eea;
                    color: white;
                    border: none;
                    padding: 10px 20px;
                    border-radius: 6px;
                    cursor: pointer;
                    font-size: 1em;
                    margin-top: 10px;
                    transition: all 0.3s;
                }
                .test-btn:hover { 
                    background: #5568d3;
                    transform: scale(1.05);
                }
                .test-btn:disabled {
                    background: #9ca3af;
                    cursor: not-allowed;
                }
                .response {
                    margin-top: 15px;
                    padding: 15px;
                    background: #1f2937;
                    color: #10b981;
                    border-radius: 6px;
                    font-family: 'Courier New', monospace;
                    font-size: 0.9em;
                    display: none;
                    white-space: pre-wrap;
                    word-break: break-all;
                }
                .status-badge {
                    display: inline-block;
                    padding: 2px 8px;
                    border-radius: 4px;
                    font-size: 0.8em;
                    font-weight: bold;
                    margin-left: 10px;
                }
                .status-200 { background: #10b981; color: white; }
                .status-201 { background: #059669; color: white; }
                .status-400 { background: #f59e0b; color: white; }
                .status-404 { background: #ef4444; color: white; }
                .status-409 { background: #dc2626; color: white; }
                input, textarea {
                    padding: 8px 12px;
                    border: 2px solid #e5e7eb;
                    border-radius: 6px;
                    font-size: 1em;
                    margin: 10px 0;
                    width: 100%;
                    font-family: inherit;
                }
                .input-row {
                    display: grid;
                    grid-template-columns: 1fr 1fr;
                    gap: 10px;
                }
                .loading {
                    display: inline-block;
                    width: 16px;
                    height: 16px;
                    border: 2px solid #fff;
                    border-top-color: transparent;
                    border-radius: 50%;
                    animation: spin 0.6s linear infinite;
                }
                @keyframes spin {
                    to { transform: rotate(360deg); }
                }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>🚀 API REST - Javalin Demo</h1>
                    <p>Teste todos os endpoints diretamente no navegador</p>
                </div>
                <div class="content">
                    <h2 class="section-title">📚 Endpoints Básicos</h2>
                    
                    <div class="endpoint">
                        <h3><span class="method get">GET</span> /hello</h3>
                        <p>Retorna uma mensagem de boas-vindas em texto simples.</p>
                        <button class="test-btn" onclick="testHello()">Testar Endpoint</button>
                        <div id="response-hello" class="response"></div>
                    </div>
                    
                    <div class="endpoint">
                        <h3><span class="method get">GET</span> /status</h3>
                        <p>Retorna o status da API com timestamp no formato ISO-8601.</p>
                        <button class="test-btn" onclick="testStatus()">Testar Endpoint</button>
                        <div id="response-status" class="response"></div>
                    </div>
                    
                    <div class="endpoint">
                        <h3><span class="method post">POST</span> /echo</h3>
                        <p>Recebe um JSON com a chave "mensagem" e retorna o mesmo conteúdo.</p>
                        <input type="text" id="echo-input" placeholder='Digite sua mensagem (ex: Teste)' value="Olá, API!">
                        <button class="test-btn" onclick="testEcho()">Testar Endpoint</button>
                        <div id="response-echo" class="response"></div>
                    </div>
                    
                    <div class="endpoint">
                        <h3><span class="method get">GET</span> /saudacao/{nome}</h3>
                        <p>Retorna uma saudação personalizada em português usando o nome fornecido.</p>
                        <input type="text" id="name-input" placeholder="Digite seu nome" value="João">
                        <button class="test-btn" onclick="testGreeting()">Testar Endpoint</button>
                        <div id="response-greeting" class="response"></div>
                    </div>
                    
                    <h2 class="section-title">👥 Endpoints CRUD - Mensalista</h2>
                    
                    <div class="endpoint">
                        <h3><span class="method post">POST</span> /mensalista</h3>
                        <p>Cria um novo mensalista. Validações: nome mínimo 3 caracteres, matrícula alfanumérica.</p>
                        <div class="input-row">
                            <input type="text" id="create-nome" placeholder="Nome (min 3 caracteres)" value="Maria Silva">
                            <input type="text" id="create-matricula" placeholder="Matrícula (alfanumérica)" value="2025001">
                        </div>
                        <button class="test-btn" onclick="testCreateMensalista()">Criar Mensalista</button>
                        <div id="response-create" class="response"></div>
                    </div>
                    
                    <div class="endpoint">
                        <h3><span class="method get">GET</span> /mensalistas</h3>
                        <p>Lista todos os mensalistas cadastrados.</p>
                        <button class="test-btn" onclick="testGetAllMensalistas()">Listar Todos</button>
                        <div id="response-getall" class="response"></div>
                    </div>
                    
                    <div class="endpoint">
                        <h3><span class="method get">GET</span> /mensalista/{matricula}</h3>
                        <p>Busca um mensalista específico pela matrícula.</p>
                        <input type="text" id="search-matricula" placeholder="Digite a matrícula" value="2025001">
                        <button class="test-btn" onclick="testGetMensalistaById()">Buscar Mensalista</button>
                        <div id="response-getone" class="response"></div>
                    </div>
                </div>
            </div>
            
            <script>
                async function makeRequest(url, options = {}) {
                    try {
                        const response = await fetch(url, options);
                        const statusCode = response.status;
                        let data;
                        
                        const contentType = response.headers.get('content-type');
                        if (contentType && contentType.includes('application/json')) {
                            data = await response.json();
                        } else {
                            data = await response.text();
                        }
                        
                        return { statusCode, data };
                    } catch (error) {
                        return { statusCode: 0, data: 'Erro: ' + error.message };
                    }
                }
                
                function showResponse(elementId, statusCode, data) {
                    const element = document.getElementById(elementId);
                    const isJson = typeof data === 'object';
                    const text = isJson ? JSON.stringify(data, null, 2) : data;
                    
                    const statusClass = 'status-' + statusCode;
                    const statusBadge = statusCode ? `<span class="status-badge ${statusClass}">HTTP ${statusCode}</span>` : '';
                    
                    element.innerHTML = statusBadge + '\\n\\n' + text;
                    element.style.display = 'block';
                }
                
                async function testHello() {
                    const { statusCode, data } = await makeRequest('/hello');
                    showResponse('response-hello', statusCode, data);
                }
                
                async function testStatus() {
                    const { statusCode, data } = await makeRequest('/status');
                    showResponse('response-status', statusCode, data);
                }
                
                async function testEcho() {
                    const message = document.getElementById('echo-input').value;
                    const { statusCode, data } = await makeRequest('/echo', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ mensagem: message })
                    });
                    showResponse('response-echo', statusCode, data);
                }
                
                async function testGreeting() {
                    const name = document.getElementById('name-input').value;
                    const { statusCode, data } = await makeRequest(`/saudacao/${encodeURIComponent(name)}`);
                    showResponse('response-greeting', statusCode, data);
                }
                
                async function testCreateMensalista() {
                    const nome = document.getElementById('create-nome').value;
                    const matricula = document.getElementById('create-matricula').value;
                    
                    const { statusCode, data } = await makeRequest('/mensalista', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ nome, matricula })
                    });
                    showResponse('response-create', statusCode, data);
                }
                
                async function testGetAllMensalistas() {
                    const { statusCode, data } = await makeRequest('/mensalistas');
                    showResponse('response-getall', statusCode, data);
                }
                
                async function testGetMensalistaById() {
                    const matricula = document.getElementById('search-matricula').value;
                    const { statusCode, data } = await makeRequest(`/mensalista/${encodeURIComponent(matricula)}`);
                    showResponse('response-getone', statusCode, data);
                }
            </script>
        </body>
        </html>
        """;
    }
}