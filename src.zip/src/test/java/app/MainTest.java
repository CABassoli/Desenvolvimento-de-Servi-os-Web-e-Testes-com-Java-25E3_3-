package app;

import io.javalin.Javalin;
import io.javalin.testtools.JavalinTest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Main Application Tests")
public class MainTest {
    
    private Javalin app;
    
    @BeforeEach
    void setUp() {
        app = Main.createApp();
    }
    
    @Test
    @DisplayName("Should return Hello, Javalin! for GET /hello")
    void testHelloEndpoint() {
        JavalinTest.test(app, (server, client) -> {
            assertDoesNotThrow(() -> {
                var response = client.get("/hello");
                assertEquals(200, response.code());
                assertEquals("Hello, Javalin!", response.body().string());
            });
        });
    }
    
    @Test
    @DisplayName("Should return status OK with timestamp for GET /status")
    void testStatusEndpoint() {
        JavalinTest.test(app, (server, client) -> {
            assertDoesNotThrow(() -> {
                var response = client.get("/status");
                assertEquals(200, response.code());
                
                String responseBody = response.body().string();
                assertTrue(responseBody.contains("\"status\":\"ok\""));
                assertTrue(responseBody.contains("\"timestamp\":"));
                assertTrue(responseBody.contains("T"));
                assertTrue(responseBody.contains("Z"));
            });
        });
    }
    
    @Test
    @DisplayName("Should echo back JSON message for POST /echo")
    void testEchoEndpoint() {
        JavalinTest.test(app, (server, client) -> {
            assertDoesNotThrow(() -> {
                String jsonBody = "{\"mensagem\":\"Teste\"}";
                var response = client.post("/echo", jsonBody);
                assertEquals(200, response.code());
                
                String responseBody = response.body().string();
                assertTrue(responseBody.contains("\"mensagem\":\"Teste\""));
            });
        });
    }
    
    @Test
    @DisplayName("Should return greeting with name for GET /saudacao/{nome}")
    void testGreetingEndpoint() {
        JavalinTest.test(app, (server, client) -> {
            assertDoesNotThrow(() -> {
                var response = client.get("/saudacao/João");
                assertEquals(200, response.code());
                
                String responseBody = response.body().string();
                assertTrue(responseBody.contains("\"mensagem\":\"Olá, João!\""));
            });
        });
    }
    
    @Test
    @DisplayName("Should handle special characters in name parameter")
    void testGreetingWithSpecialCharacters() {
        JavalinTest.test(app, (server, client) -> {
            assertDoesNotThrow(() -> {
                var response = client.get("/saudacao/José");
                assertEquals(200, response.code());
                
                String responseBody = response.body().string();
                assertTrue(responseBody.contains("\"mensagem\":\"Olá, José!\""));
            });
        });
    }
    
    @Test
    @DisplayName("Should handle invalid JSON for POST /echo")
    void testEchoWithInvalidJson() {
        JavalinTest.test(app, (server, client) -> {
            assertDoesNotThrow(() -> {
                String invalidJson = "{invalid json}";
                var response = client.post("/echo", invalidJson);
                assertEquals(400, response.code());
                
                String responseBody = response.body().string();
                assertTrue(responseBody.contains("\"error\""));
            });
        });
    }
}