package app;

import io.javalin.Javalin;
import io.javalin.testtools.JavalinTest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import app.handlers.MensalistaHandler;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Testes da API - Rubrica 2")
public class MensalistaApiTest {
    
    private Javalin app;
    
    @BeforeEach
    void setUp() {
        app = Main.createApp();
        MensalistaHandler.clearAll();
    }
    
    @Test
    @DisplayName("Teste 1 - GET /hello deve retornar status 200 OK e a string 'Hello, Javalin!'")
    void testHelloEndpoint() {
        JavalinTest.test(app, (server, client) -> {
            assertDoesNotThrow(() -> {
                var response = client.get("/hello");
                
                assertEquals(200, response.code(), "Status deve ser 200 OK");
                assertEquals("Hello, Javalin!", response.body().string(), 
                    "Corpo da resposta deve ser 'Hello, Javalin!'");
            });
        });
    }
    
    @Test
    @DisplayName("Teste 2 - POST /mensalista deve criar um novo Mensalista e retornar status 201 Created")
    void testCreateMensalista() {
        JavalinTest.test(app, (server, client) -> {
            assertDoesNotThrow(() -> {
                String jsonBody = """
                    {
                        "nome": "João Silva",
                        "matricula": "2024001"
                    }
                    """;
                
                var response = client.post("/mensalista", jsonBody);
                
                assertEquals(201, response.code(), "Status deve ser 201 Created");
                
                String responseBody = response.body().string();
                assertTrue(responseBody.contains("\"nome\":\"João Silva\""), 
                    "Resposta deve conter o nome do mensalista");
                assertTrue(responseBody.contains("\"matricula\":\"2024001\""), 
                    "Resposta deve conter a matrícula do mensalista");
            });
        });
    }
    
    @Test
    @DisplayName("Teste 3 - GET /mensalista/{matricula} deve buscar um Mensalista por matrícula e retornar status 200 OK com dados corretos")
    void testGetMensalistaByMatricula() {
        JavalinTest.test(app, (server, client) -> {
            assertDoesNotThrow(() -> {
                String jsonBody = """
                    {
                        "nome": "Maria Santos",
                        "matricula": "2024002"
                    }
                    """;
                
                var createResponse = client.post("/mensalista", jsonBody);
                assertEquals(201, createResponse.code(), "Mensalista deve ser criado com sucesso");
                
                var getResponse = client.get("/mensalista/2024002");
                
                assertEquals(200, getResponse.code(), "Status deve ser 200 OK");
                
                String responseBody = getResponse.body().string();
                assertTrue(responseBody.contains("\"nome\":\"Maria Santos\""), 
                    "Resposta deve conter o nome correto do mensalista");
                assertTrue(responseBody.contains("\"matricula\":\"2024002\""), 
                    "Resposta deve conter a matrícula correta do mensalista");
            });
        });
    }
    
    @Test
    @DisplayName("Teste 4 - GET /mensalistas deve retornar status 200 OK e array JSON com pelo menos 1 item após cadastro")
    void testGetAllMensalistas() {
        JavalinTest.test(app, (server, client) -> {
            assertDoesNotThrow(() -> {
                String jsonBody = """
                    {
                        "nome": "Pedro Oliveira",
                        "matricula": "2024003"
                    }
                    """;
                
                var createResponse = client.post("/mensalista", jsonBody);
                assertEquals(201, createResponse.code(), "Mensalista deve ser criado com sucesso");
                
                var getAllResponse = client.get("/mensalistas");
                
                assertEquals(200, getAllResponse.code(), "Status deve ser 200 OK");
                
                String responseBody = getAllResponse.body().string();
                assertTrue(responseBody.startsWith("["), "Resposta deve ser um array JSON");
                assertTrue(responseBody.contains("\"nome\":\"Pedro Oliveira\""), 
                    "Lista deve conter pelo menos o mensalista cadastrado");
                assertFalse(responseBody.equals("[]"), 
                    "Lista não deve estar vazia após o cadastro");
            });
        });
    }
    
    @Test
    @DisplayName("Teste 5 (Rubrica 4) - POST /mensalista deve retornar 400 Bad Request se nome tiver menos de 3 caracteres")
    void testCreateMensalistaWithShortNome() {
        JavalinTest.test(app, (server, client) -> {
            assertDoesNotThrow(() -> {
                String jsonBody = """
                    {
                        "nome": "AB",
                        "matricula": "2024010"
                    }
                    """;
                
                var response = client.post("/mensalista", jsonBody);
                
                assertEquals(400, response.code(), "Status deve ser 400 Bad Request");
                
                String responseBody = response.body().string();
                assertTrue(responseBody.contains("Nome deve ter pelo menos 3 caracteres"), 
                    "Mensagem de erro deve indicar que nome deve ter pelo menos 3 caracteres");
            });
        });
    }
    
    @Test
    @DisplayName("Teste 6 (Rubrica 4) - POST /mensalista deve retornar 400 Bad Request se matrícula não for alfanumérica")
    void testCreateMensalistaWithNonAlphanumericMatricula() {
        JavalinTest.test(app, (server, client) -> {
            assertDoesNotThrow(() -> {
                String jsonBody = """
                    {
                        "nome": "Carlos Souza",
                        "matricula": "2024@#$"
                    }
                    """;
                
                var response = client.post("/mensalista", jsonBody);
                
                assertEquals(400, response.code(), "Status deve ser 400 Bad Request");
                
                String responseBody = response.body().string();
                assertTrue(responseBody.contains("Matrícula deve ser alfanumérica"), 
                    "Mensagem de erro deve indicar que matrícula deve ser alfanumérica");
            });
        });
    }
    
    @Test
    @DisplayName("Teste 7 (Rubrica 4) - POST /mensalista deve retornar 409 Conflict se matrícula já existir")
    void testCreateMensalistaWithDuplicateMatricula() {
        JavalinTest.test(app, (server, client) -> {
            assertDoesNotThrow(() -> {
                String jsonBody = """
                    {
                        "nome": "Ana Paula",
                        "matricula": "2024020"
                    }
                    """;
                
                var firstResponse = client.post("/mensalista", jsonBody);
                assertEquals(201, firstResponse.code(), "Primeira criação deve retornar 201 Created");
                
                var duplicateResponse = client.post("/mensalista", jsonBody);
                
                assertEquals(409, duplicateResponse.code(), "Status deve ser 409 Conflict");
                
                String responseBody = duplicateResponse.body().string();
                assertTrue(responseBody.contains("matrícula já existe"), 
                    "Mensagem de erro deve indicar que matrícula já existe");
            });
        });
    }
    
    @Test
    @DisplayName("Teste 8 (Rubrica 4) - GET /mensalista/{matricula} deve retornar 404 Not Found se matrícula não existir")
    void testGetMensalistaNotFound() {
        JavalinTest.test(app, (server, client) -> {
            assertDoesNotThrow(() -> {
                var response = client.get("/mensalista/INEXISTENTE");
                
                assertEquals(404, response.code(), "Status deve ser 404 Not Found");
                
                String responseBody = response.body().string();
                assertTrue(responseBody.contains("não encontrado"), 
                    "Mensagem de erro deve indicar que mensalista não foi encontrado");
            });
        });
    }
}