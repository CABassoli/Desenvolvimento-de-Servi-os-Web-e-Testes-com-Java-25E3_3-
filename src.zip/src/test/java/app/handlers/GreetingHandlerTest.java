package app.handlers;

import io.javalin.http.Context;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Map;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@DisplayName("GreetingHandler Tests")
public class GreetingHandlerTest {
    
    @Mock
    private Context ctx;
    
    private GreetingHandler greetingHandler;
    
    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        greetingHandler = new GreetingHandler();
    }
    
    @Test
    @DisplayName("Should return greeting with provided name")
    void testHandleGreetingRequest() throws Exception {
        // Preparar
        when(ctx.pathParam("nome")).thenReturn("João");
        
        // Executar
        greetingHandler.handle(ctx);
        
        // Verificar
        verify(ctx).json(any(Map.class));
    }
    
    @Test
    @DisplayName("Should handle names with special characters")
    void testHandleGreetingWithSpecialCharacters() throws Exception {
        // Preparar
        when(ctx.pathParam("nome")).thenReturn("José");
        
        // Executar
        greetingHandler.handle(ctx);
        
        // Verificar
        verify(ctx).json(any(Map.class));
    }
}