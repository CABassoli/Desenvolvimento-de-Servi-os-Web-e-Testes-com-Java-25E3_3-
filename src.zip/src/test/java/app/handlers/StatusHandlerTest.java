package app.handlers;

import io.javalin.http.Context;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.time.Instant;
import java.time.format.DateTimeFormatter;
import java.util.Map;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@DisplayName("StatusHandler Tests")
public class StatusHandlerTest {
    
    @Mock
    private Context ctx;
    
    private StatusHandler statusHandler;
    
    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        statusHandler = new StatusHandler();
    }
    
    @Test
    @DisplayName("Should return status OK with valid timestamp")
    void testHandleStatusRequest() throws Exception {
        // Executar
        statusHandler.handle(ctx);
        
        // Verificar que o método json é chamado com estrutura correta
        verify(ctx).json(any(Map.class));
    }
}