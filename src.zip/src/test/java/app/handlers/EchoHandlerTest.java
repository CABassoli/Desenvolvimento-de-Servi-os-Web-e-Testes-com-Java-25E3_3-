package app.handlers;

import io.javalin.http.Context;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.HashMap;
import java.util.Map;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@DisplayName("EchoHandler Tests")
public class EchoHandlerTest {
    
    @Mock
    private Context ctx;
    
    private EchoHandler echoHandler;
    
    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        echoHandler = new EchoHandler();
    }
    
    @Test
    @DisplayName("Should echo back valid JSON")
    void testHandleEchoWithValidJson() throws Exception {
        // Preparar
        Map<String, Object> requestBody = new HashMap<>();
        requestBody.put("mensagem", "Teste");
        when(ctx.bodyAsClass(Map.class)).thenReturn(requestBody);
        
        // Executar
        echoHandler.handle(ctx);
        
        // Verificar
        verify(ctx).json(requestBody);
    }
    
    @Test
    @DisplayName("Should handle invalid JSON with error response")
    void testHandleEchoWithInvalidJson() throws Exception {
        // Preparar
        when(ctx.bodyAsClass(Map.class)).thenThrow(new RuntimeException("Invalid JSON"));
        when(ctx.status(400)).thenReturn(ctx); // Corrige encadeamento de métodos
        
        // Executar
        echoHandler.handle(ctx);
        
        // Verificar
        verify(ctx).status(400);
        verify(ctx).json(any(Map.class));
    }
}