#!/bin/bash

# Script para executar o cliente REST
cd "$(dirname "$0")"

# Compilar se necessário
if [ ! -d "target/classes" ]; then
    echo "Compilando projeto..."
    mvn compile -q
fi

# Obter classpath do Maven
CP=$(mvn dependency:build-classpath -q -DincludeScope=runtime -Dmdep.outputFile=/dev/stdout)

# Executar o cliente
java -cp "target/classes:$CP" client.Main
