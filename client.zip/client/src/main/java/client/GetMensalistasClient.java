package client;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class GetMensalistasClient {
    
    private static final String BASE_URL = "http://localhost:5000";
    
    public static void listarMensalistas() {
        try {
            URL url = new URL(BASE_URL + "/mensalistas");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            
            int statusCode = conn.getResponseCode();
            System.out.println("Status Code: " + statusCode);
            
            BufferedReader br = new BufferedReader(
                new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8)
            );
            
            StringBuilder response = new StringBuilder();
            String responseLine;
            while ((responseLine = br.readLine()) != null) {
                response.append(responseLine.trim());
            }
            
            System.out.println("Resposta: " + response.toString());
            
            br.close();
            conn.disconnect();
            
        } catch (Exception e) {
            System.err.println("Erro ao listar mensalistas: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    public static void main(String[] args) {
        System.out.println("=== Cliente GET /mensalistas ===");
        listarMensalistas();
    }
}