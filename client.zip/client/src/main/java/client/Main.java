package client;

import java.util.Scanner;

public class Main {
    
    private static final Scanner scanner = new Scanner(System.in);
    
    public static void main(String[] args) {
        System.out.println("========================================");
        System.out.println("  Cliente REST - API Javalin Demo");
        System.out.println("========================================");
        System.out.println();
        
        boolean continuar = true;
        
        while (continuar) {
            exibirMenu();
            int opcao = lerOpcao();
            System.out.println();
            
            switch (opcao) {
                case 1:
                    testarPostMensalista();
                    break;
                case 2:
                    testarGetMensalistas();
                    break;
                case 3:
                    testarGetMensalistaPorMatricula();
                    break;
                case 4:
                    testarGetStatus();
                    break;
                case 5:
                    testarTodos();
                    break;
                case 0:
                    continuar = false;
                    System.out.println("Encerrando cliente REST...");
                    break;
                default:
                    System.out.println("Opção inválida! Tente novamente.");
            }
            
            if (continuar) {
                System.out.println();
                System.out.println("Pressione ENTER para continuar...");
                scanner.nextLine();
                System.out.println();
            }
        }
        
        scanner.close();
    }
    
    private static void exibirMenu() {
        System.out.println("┌─────────────────────────────────────┐");
        System.out.println("│           MENU PRINCIPAL            │");
        System.out.println("├─────────────────────────────────────┤");
        System.out.println("│ 1. Criar Mensalista (POST)          │");
        System.out.println("│ 2. Listar Mensalistas (GET)         │");
        System.out.println("│ 3. Buscar por Matrícula (GET)       │");
        System.out.println("│ 4. Verificar Status da API (GET)    │");
        System.out.println("│ 5. Testar TODOS os endpoints        │");
        System.out.println("│ 0. Sair                             │");
        System.out.println("└─────────────────────────────────────┘");
        System.out.print("Escolha uma opção: ");
    }
    
    private static int lerOpcao() {
        try {
            String input = scanner.nextLine();
            return Integer.parseInt(input);
        } catch (NumberFormatException e) {
            return -1;
        }
    }
    
    private static void testarPostMensalista() {
        System.out.println("=== CRIAR MENSALISTA (POST) ===");
        System.out.print("Digite o nome: ");
        String nome = scanner.nextLine();
        System.out.print("Digite a matrícula: ");
        String matricula = scanner.nextLine();
        System.out.println();
        
        PostMensalistaClient.criarMensalista(nome, matricula);
    }
    
    private static void testarGetMensalistas() {
        System.out.println("=== LISTAR MENSALISTAS (GET) ===");
        System.out.println();
        GetMensalistasClient.listarMensalistas();
    }
    
    private static void testarGetMensalistaPorMatricula() {
        System.out.println("=== BUSCAR POR MATRÍCULA (GET) ===");
        System.out.print("Digite a matrícula: ");
        String matricula = scanner.nextLine();
        System.out.println();
        
        GetMensalistaPorMatriculaClient.buscarPorMatricula(matricula);
    }
    
    private static void testarGetStatus() {
        System.out.println("=== VERIFICAR STATUS DA API (GET) ===");
        System.out.println();
        GetStatusClient.verificarStatus();
    }
    
    private static void testarTodos() {
        System.out.println("=== TESTANDO TODOS OS ENDPOINTS ===");
        System.out.println();
        
        System.out.println("1. Verificando Status da API...");
        System.out.println("-----------------------------------");
        GetStatusClient.verificarStatus();
        System.out.println();
        
        System.out.println("2. Criando Mensalista de Teste...");
        System.out.println("-----------------------------------");
        String matriculaTeste = "TEST" + System.currentTimeMillis();
        PostMensalistaClient.criarMensalista("Teste Automático", matriculaTeste);
        System.out.println();
        
        System.out.println("3. Listando Todos os Mensalistas...");
        System.out.println("-----------------------------------");
        GetMensalistasClient.listarMensalistas();
        System.out.println();
        
        System.out.println("4. Buscando Mensalista Criado...");
        System.out.println("-----------------------------------");
        GetMensalistaPorMatriculaClient.buscarPorMatricula(matriculaTeste);
        System.out.println();
        
        System.out.println("=== TESTE COMPLETO FINALIZADO ===");
    }
}