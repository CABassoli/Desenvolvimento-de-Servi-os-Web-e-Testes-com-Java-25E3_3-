package client;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class PostMensalistaClient {
    
    private static final String BASE_URL = "http://localhost:5000";
    private static final Gson gson = new Gson();
    
    public static void criarMensalista(String nome, String matricula) {
        try {
            URL url = new URL(BASE_URL + "/mensalista");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setDoOutput(true);
            
            JsonObject json = new JsonObject();
            json.addProperty("nome", nome);
            json.addProperty("matricula", matricula);
            
            String jsonInputString = gson.toJson(json);
            
            try (OutputStream os = conn.getOutputStream()) {
                byte[] input = jsonInputString.getBytes(StandardCharsets.UTF_8);
                os.write(input, 0, input.length);
            }
            
            int statusCode = conn.getResponseCode();
            System.out.println("Status Code: " + statusCode);
            
            BufferedReader br;
            if (statusCode >= 200 && statusCode < 300) {
                br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
            } else {
                br = new BufferedReader(new InputStreamReader(conn.getErrorStream(), StandardCharsets.UTF_8));
            }
            
            StringBuilder response = new StringBuilder();
            String responseLine;
            while ((responseLine = br.readLine()) != null) {
                response.append(responseLine.trim());
            }
            
            System.out.println("Resposta: " + response.toString());
            
            br.close();
            conn.disconnect();
            
        } catch (Exception e) {
            System.err.println("Erro ao criar mensalista: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    public static void main(String[] args) {
        System.out.println("=== Cliente POST /mensalista ===");
        criarMensalista("João Silva", "2024001");
    }
}