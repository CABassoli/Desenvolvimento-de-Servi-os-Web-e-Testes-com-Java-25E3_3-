#!/bin/bash

# Script para testar todos os clientes REST
cd "$(dirname "$0")"

# Compilar se necessário
if [ ! -d "target/classes" ]; then
    echo "Compilando projeto..."
    mvn compile -q
fi

# Obter Gson do repositório Maven local
GSON_JAR="$HOME/.m2/repository/com/google/code/gson/gson/2.10.1/gson-2.10.1.jar"

echo "========================================"
echo "  Testando Clientes REST - Javalin API"
echo "========================================"
echo ""

echo "1. Testando GET /status"
echo "----------------------------------------"
java -cp "target/classes:$GSON_JAR" client.GetStatusClient
echo ""

echo "2. Testando POST /mensalista"
echo "----------------------------------------"
java -cp "target/classes:$GSON_JAR" client.PostMensalistaClient
echo ""

echo "3. Testando GET /mensalistas"
echo "----------------------------------------"
java -cp "target/classes:$GSON_JAR" client.GetMensalistasClient
echo ""

echo "4. Testando GET /mensalista/{matricula}"
echo "----------------------------------------"
java -cp "target/classes:$GSON_JAR" client.GetMensalistaPorMatriculaClient 2024001
echo ""

echo "========================================"
echo "  Todos os testes concluídos!"
echo "========================================"
